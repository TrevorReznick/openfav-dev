const _url = 'https://open-favs.vercel.app'
const sessionAuthUrl = _url + '/api/v2/auth/signin'
const YOUR_TOKEN = '89773db3-7863-460c-ad3c-6abd0db43f1c'
const API_URL = 'https://vnavarra.nuvolaris.dev/api/my/openfavs/assistant?name=enzo'

let user_id = null

document.querySelector('#saveButton').addEventListener('click', () => {

    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {

        const activeTab = tabs[0]
        const url = activeTab.url

        try {
            const isAuthenticated = await checkAuth()
            if (isAuthenticated) {
                const aiResponse = await testAIBackend()
                alert(JSON.stringify(aiResponse.body))
                const sessionInfo = await getSessionInfo()
                user_id = sessionInfo.session.user.id
                alert(`Authenticated as user: ${user_id}`)
            } else {
                showLoginPrompt()
            }
        } catch (error) {
            alert('Errore: ' + error.message)
        }
    })
})

// Funzione per verificare se l'utente è autenticato
async function checkAuth() {
  return new Promise((resolve, reject) => {
    chrome.cookies.getAll({ url: _url }, function (cookies) {
      let isAuthenticated = false
      for (let i = 0; i < cookies.length; i++) {
        if (cookies[i].name === 'sb-access-token') {
          isAuthenticated = true
          break
        }
      }
      resolve(isAuthenticated)
    })
  })
}

// Funzione per testare l'AI backend
async function testAIBackend() {
  const response = await fetch(API_URL, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${YOUR_TOKEN}`,
      'Content-Type': 'application/json'
    }
  })

  if (!response.ok) {
    throw new Error('Errore nella richiesta')
  }

  return response.json()
}

// Funzione per ottenere le informazioni di sessione
async function getSessionInfo() {
  const response = await fetch(sessionAuthUrl, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  })

  if (!response.ok) {
    throw new Error('Errore nel recupero delle informazioni di sessione')
  }

  return response.json()
}

// Funzione per mostrare il prompt di login
function showLoginPrompt() {
  document.body.innerHTML = `
    <h3>Save Current Site</h3>
    <p>You need to be authenticated to use OpenFavs.</p>
    <button id="loginButton">Login</button>
  `
  
  document.querySelector('#loginButton').addEventListener('click', () => {
    window.open('https://open-favs.vercel.app/login/signin', '_blank')
  })
}
